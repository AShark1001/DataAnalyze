# Changelog

## 1.2
* Added Flask-Login 
* Added Modernizr
* updated css and js libraries
* removed typelate

## 1.1
* switched to py.test for tests
* form tests
* url tests
* testing database submitting on model tests
* added documentation on how to deploy your application

## 1.0
* MVC with blueprints, SQLAlchemy models, and templates
* A makefile
* nose tests
* Flask-Assets css and js management
* Flask-Cache for caching jinja templates
* A Flask-Script management script
* Flask-WTF form management